function add(text = '') {
    const note = document.createElement('div');
    note.classList.add('inputs');
    const studentHeading = document.createElement('h2');
    studentHeading.innerText = "Enter Student Data";
    note.appendChild(studentHeading);
    const inputFirstName = document.createElement('input');
    inputFirstName.type = "text";
    inputFirstName.placeholder = "First name";
    inputFirstName.classList.add("in", "fname");
    inputFirstName.value = text.fname || '';
    note.appendChild(inputFirstName);
    note.appendChild(document.createElement('br'));
    const inputLastName = document.createElement('input');
    inputLastName.type = "text";
    inputLastName.placeholder = "Last name";
    inputLastName.classList.add("in", "lname");
    inputLastName.value = text.lname || '';
    note.appendChild(inputLastName);
    note.appendChild(document.createElement('br'));
    const inputAge = document.createElement('input');
    inputAge.type = "text";
    inputAge.placeholder = "Age";
    inputAge.classList.add("in", "age");
    inputAge.value = text.age || '';
    note.appendChild(inputAge);
    note.appendChild(document.createElement('br'));
    const inputAddress = document.createElement('input');
    inputAddress.type = "text";
    inputAddress.placeholder = "Address";
    inputAddress.classList.add("in", "address");
    inputAddress.value = text.address || '';
    note.appendChild(inputAddress);
    note.appendChild(document.createElement('br'));
    const saveButton = document.createElement('button');
    saveButton.innerText = "Save";
    saveButton.id = "save";
    note.appendChild(saveButton);
    const editButton = document.createElement('button');
    editButton.innerText = "Edit";
    editButton.id = "edit";
    editButton.style.display = 'none';
    note.appendChild(editButton);
    const deleteButton = document.createElement('button');
    deleteButton.innerText = "Delete";
    deleteButton.id = "del";
    note.appendChild(deleteButton);
    function deleteNote() {
        note.remove();
        updateLocalStorage();
    }
    deleteButton.addEventListener('click', deleteNote);
    function saveData() {
        const fname = note.querySelector('.fname').value;
        const lname = note.querySelector('.lname').value;
        const age = note.querySelector('.age').value;
        const address = note.querySelector('.address').value;
        const studentsData = JSON.parse(localStorage.getItem('studentsData')) || [];
        studentsData.push({ fname, lname, age, address });
        localStorage.setItem('studentsData', JSON.stringify(studentsData));
        updateLocalStorage();
        enableInputs(false);
        saveButton.style.display = 'none';
        editButton.style.display = 'inline-block';
    }
    saveButton.addEventListener('click', saveData);
    function enableInputs(enable) {
        const inputs = note.querySelectorAll('.in');
        function disableInputs(input) {
            input.disabled = !enable;
        }
        inputs.forEach(disableInputs);
    }
    function editData() {
        enableInputs(true);
        saveButton.style.display = 'inline-block';
        editButton.style.display = 'none';
    }
    editButton.addEventListener('click', editData);
    if (text) {
        enableInputs(false);
        saveButton.style.display = 'none';
        editButton.style.display = 'inline-block';
    }
    document.body.appendChild(note);
}
const savedData = localStorage.getItem('studentsData');
if (savedData) {
    const students = JSON.parse(savedData);
    function showData(student) {
        add(student);
    }
    students.forEach(showData);
}
function updateLocalStorage() {
    const notes = document.querySelectorAll('.inputs');
    const studentsData = [];
    function updateData(note) {
        const fname = note.querySelector('.fname').value;
        const lname = note.querySelector('.lname').value;
        const age = note.querySelector('.age').value;
        const address = note.querySelector('.address').value;
        studentsData.push({ fname, lname, age, address });
    }
    notes.forEach(updateData);
    localStorage.setItem('studentsData', JSON.stringify(studentsData));
}